package com.magna.documents

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF101114)
private val Panel = Color(0xFF1B1D22)
private val Accent = Color(0xFFE5E5E5)

class MainActivity : ComponentActivity() {
    private lateinit var library: File

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        library = File(filesDir, "MAGNA").apply { mkdirs() }
        File(library, "Inbox").mkdirs()
        handleIncoming(intent)
        setContent { MagnaApp(this, library) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncoming(intent)
    }

    private fun handleIncoming(i: Intent?) {
        if (i == null) return
        val uris = mutableListOf<Uri>()
        if (i.action == Intent.ACTION_SEND && i.type?.startsWith("image/") == true) {
            (i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM))?.let { uris.add(it) }
        } else if (i.action == Intent.ACTION_SEND_MULTIPLE) {
            i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)?.let { uris.addAll(it) }
        }
        uris.forEach { copyUriToInbox(this, it, library) }
    }
}

private fun copyUriToInbox(context: Context, uri: Uri, root: File) {
    runCatching {
        val name = "IMG_${System.currentTimeMillis()}.jpg"
        val target = File(File(root, "Inbox"), name)
        context.contentResolver.openInputStream(uri)?.use { input ->
            target.outputStream().use { output -> input.copyTo(output) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MagnaApp(context: Context, root: File) {
    var currentFolder by remember { mutableStateOf(root) }
    var refresh by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<File?>(null) }
    var showNewFolder by remember { mutableStateOf(false) }
    var folderName by remember { mutableStateOf("") }
    var resizeFile by remember { mutableStateOf<File?>(null) }
    var widthText by remember { mutableStateOf("1200") }
    var heightText by remember { mutableStateOf("1600") }
    var quality by remember { mutableFloatStateOf(82f) }
    var notice by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        uris.forEach { copyUriToInbox(context, it, root) }
        refresh++
    }

    val files = remember(currentFolder, refresh) {
        currentFolder.listFiles()?.filter { it.isFile && it.extension.lowercase() in listOf("jpg","jpeg","png","webp") }
            ?.sortedByDescending { it.lastModified() } ?: emptyList()
    }
    val folders = remember(root, refresh) { root.listFiles()?.filter { it.isDirectory }?.sortedBy { it.name } ?: emptyList() }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Accent, onPrimary = Bg,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("MAGNA", fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                            Text(currentFolder.name, fontSize = 11.sp, color = Color.LightGray)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg),
                    actions = {
                        IconButton(onClick = { showNewFolder = true }) { Icon(Icons.Default.CreateNewFolder, "New folder") }
                        IconButton(onClick = { picker.launch("image/*") }) { Icon(Icons.Default.AddPhotoAlternate, "Import images") }
                    }
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { picker.launch("image/*") }, containerColor = Color.White, contentColor = Bg) {
                    Icon(Icons.Default.Add, "Import")
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize().padding(horizontal = 16.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    QuickAction("Import", Icons.Default.Image, { picker.launch("image/*") }, Modifier.weight(1f))
                    QuickAction("New folder", Icons.Default.Folder, { showNewFolder = true }, Modifier.weight(1f))
                    QuickAction("Clean up", Icons.Default.CleaningServices, {
                        val count = currentFolder.listFiles()?.count { it.isFile && it.length() == 0L } ?: 0
                        notice = "$count empty files found. No files were deleted."
                    }, Modifier.weight(1f))
                }
                Spacer(Modifier.height(16.dp))
                if (currentFolder != root) {
                    Text("‹ All folders", color = Color.LightGray, modifier = Modifier.clickable { currentFolder = root }.padding(vertical = 8.dp))
                }
                if (currentFolder == root) {
                    Text("FOLDERS", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    folders.forEach { folder ->
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 5.dp).background(Panel, RoundedCornerShape(12.dp))
                                .clickable { currentFolder = folder }.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Folder, null, tint = Color(0xFFE7C77A))
                            Spacer(Modifier.width(12.dp))
                            Text(folder.name, Modifier.weight(1f))
                            Text("${folder.listFiles()?.size ?: 0}", color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("IMAGES", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                if (files.isEmpty()) {
                    Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        Text("No images yet\nImport or share images to MAGNA", color = Color.Gray)
                    }
                } else {
                    LazyVerticalGrid(columns = GridCells.Fixed(2), contentPadding = PaddingValues(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(files) { file ->
                            Column(Modifier.background(Panel, RoundedCornerShape(12.dp)).clickable { selected = file }.padding(10.dp)) {
                                Box(Modifier.fillMaxWidth().height(112.dp).background(Color(0xFF292B30), RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.Image, null, tint = Color.LightGray, modifier = Modifier.size(42.dp))
                                }
                                Spacer(Modifier.height(8.dp))
                                Text(file.name, maxLines = 1, fontSize = 12.sp)
                                Text(formatBytes(file.length()), color = Color.Gray, fontSize = 10.sp)
                                Row {
                                    Text("Resize", color = Color.White, fontSize = 11.sp, modifier = Modifier.clickable { resizeFile = file }.padding(5.dp))
                                    Text("PDF", color = Color.White, fontSize = 11.sp, modifier = Modifier.clickable { exportPdf(context, listOf(file), root); notice = "PDF exported to Downloads" }.padding(5.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showNewFolder) {
            AlertDialog(
                onDismissRequest = { showNewFolder = false },
                title = { Text("Create folder") },
                text = { OutlinedTextField(folderName, { folderName = it }, label = { Text("Folder name") }) },
                confirmButton = { TextButton(onClick = {
                    val safe = folderName.trim().replace("/", "_")
                    if (safe.isNotBlank()) File(root, safe).mkdirs()
                    folderName = ""; showNewFolder = false; refresh++
                }) { Text("Create") } },
                dismissButton = { TextButton(onClick = { showNewFolder = false }) { Text("Cancel") } }
            )
        }

        selected?.let { file ->
            AlertDialog(
                onDismissRequest = { selected = null },
                title = { Text(file.name) },
                text = { Column {
                    Text(formatBytes(file.length()), color = Color.Gray)
                    Spacer(Modifier.height(12.dp))
                    Text("Resize", Modifier.fillMaxWidth().clickable { resizeFile = file; selected = null }.padding(8.dp))
                    Text("Rotate 90°", Modifier.fillMaxWidth().clickable { rotateImage(file); refresh++; selected = null }.padding(8.dp))
                    Text("Export as PDF", Modifier.fillMaxWidth().clickable { exportPdf(context, listOf(file), root); notice = "PDF exported to Downloads"; selected = null }.padding(8.dp))
                    Text("Share image", Modifier.fillMaxWidth().clickable { shareFile(context, file, "image/jpeg"); selected = null }.padding(8.dp))
                    Text("Delete", color = Color.Red, modifier = Modifier.fillMaxWidth().clickable { file.delete(); refresh++; selected = null }.padding(8.dp))
                } },
                confirmButton = { TextButton(onClick = { selected = null }) { Text("Close") } }
            )
        }

        resizeFile?.let { file ->
            AlertDialog(
                onDismissRequest = { resizeFile = null },
                title = { Text("Resize image") },
                text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(widthText, { widthText = it }, label = { Text("Width (px)") })
                    OutlinedTextField(heightText, { heightText = it }, label = { Text("Height (px)") })
                    Text("JPEG quality: ${quality.toInt()}%")
                    Slider(value = quality, onValueChange = { quality = it }, valueRange = 30f..100f)
                } },
                confirmButton = { TextButton(onClick = {
                    val out = resizeImage(file, widthText.toIntOrNull() ?: 1200, heightText.toIntOrNull() ?: 1600, quality.toInt())
                    if (out != null) { notice = "Resized copy saved: ${out.name}"; refresh++ }
                    resizeFile = null
                }) { Text("Save copy") } },
                dismissButton = { TextButton(onClick = { resizeFile = null }) { Text("Cancel") } }
            )
        }
        if (notice.isNotBlank()) {
            AlertDialog(onDismissRequest = { notice = "" }, confirmButton = { TextButton(onClick = { notice = "" }) { Text("OK") } }, text = { Text(notice) })
        }
    }
}

@Composable
private fun QuickAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, action: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(12.dp)).clickable { action() }.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = Color.White)
        Spacer(Modifier.height(4.dp))
        Text(label, fontSize = 11.sp, color = Color.White)
    }
}

private fun resizeImage(file: File, width: Int, height: Int, quality: Int): File? = runCatching {
    val source = BitmapFactory.decodeFile(file.absolutePath) ?: return null
    val ratio = minOf(width.toFloat() / source.width, height.toFloat() / source.height)
    val w = (source.width * ratio).toInt().coerceAtLeast(1)
    val h = (source.height * ratio).toInt().coerceAtLeast(1)
    val resized = Bitmap.createScaledBitmap(source, w, h, true)
    val out = File(file.parentFile, file.nameWithoutExtension + "_resized.jpg")
    FileOutputStream(out).use { resized.compress(Bitmap.CompressFormat.JPEG, quality.coerceIn(30,100), it) }
    source.recycle(); resized.recycle()
    out
}.getOrNull()

private fun rotateImage(file: File) {
    runCatching {
        val src = BitmapFactory.decodeFile(file.absolutePath) ?: return
        val matrix = Matrix().apply { postRotate(90f) }
        val rotated = Bitmap.createBitmap(src, 0, 0, src.width, src.height, matrix, true)
        FileOutputStream(file).use { rotated.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        src.recycle(); rotated.recycle()
    }
}

private fun exportPdf(context: Context, images: List<File>, root: File) {
    runCatching {
        val pdf = PdfDocument()
        images.forEachIndexed { index, file ->
            val bitmap = BitmapFactory.decodeFile(file.absolutePath) ?: return@forEachIndexed
            val scale = minOf(595f / bitmap.width, 842f / bitmap.height)
            val w = (bitmap.width * scale).toInt()
            val h = (bitmap.height * scale).toInt()
            val page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, index + 1).create())
            val scaled = Bitmap.createScaledBitmap(bitmap, w, h, true)
            page.canvas.drawBitmap(scaled, (595-w)/2f, (842-h)/2f, Paint(Paint.FILTER_BITMAP_FLAG))
            pdf.finishPage(page)
            bitmap.recycle(); scaled.recycle()
        }
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, "MAGNA_${System.currentTimeMillis()}.pdf")
            put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)!!
        context.contentResolver.openOutputStream(uri)!!.use { pdf.writeTo(it) }
        values.clear(); values.put(MediaStore.Downloads.IS_PENDING, 0)
        context.contentResolver.update(uri, values, null, null)
        pdf.close()
    }
}

private fun shareFile(context: Context, file: File, mime: String) {
    // Sharing via FileProvider will be enabled in a later build; use Android Sharesheet for MediaStore exports.
    val values = ContentValues().apply { put(MediaStore.Images.Media.DISPLAY_NAME, file.name); put(MediaStore.Images.Media.MIME_TYPE, mime) }
    val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
    if (uri != null) {
        context.contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
        val intent = Intent(Intent.ACTION_SEND).apply { type = mime; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        context.startActivity(Intent.createChooser(intent, "Share image"))
    }
}

private fun formatBytes(bytes: Long): String = when {
    bytes >= 1024*1024 -> String.format(Locale.US, "%.1f MB", bytes / 1024f / 1024f)
    bytes >= 1024 -> String.format(Locale.US, "%.0f KB", bytes / 1024f)
    else -> "$bytes B"
}
